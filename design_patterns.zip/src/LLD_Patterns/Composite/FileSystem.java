package LLD_Patterns.Composite;

public interface FileSystem {
	void printName();
}
