package LLD_Patterns.Composite.Calculator;

public interface Calculate {
	int evaluate();
}
