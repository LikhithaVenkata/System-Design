package LLD_Patterns.Composite.Calculator;

public enum Operation {
	ADD,
	SUB,
	MUL,
	DIV;
	
}
