package LLD_Patterns.Observer;

public interface Observer {
	public void update(int temperature);
}
