package LLD_Patterns.Strategy;

public class NormalDrive implements Strategy{

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("It's normal drive");
	}
	
}
