package LLD_Patterns.Strategy;

public interface Strategy {
		public void drive();
}
