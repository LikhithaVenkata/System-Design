package LLD_Patterns.Strategy;

public class SportsDrive implements Strategy{

	@Override
	public void drive() {
		System.out.println("It's sports drive");		
	}

}
