package LLD_Patterns.Strategy;

public class SportsVechile extends Vechile{

	public SportsVechile() {
		super(new SportsDrive());
		// TODO Auto-generated constructor stub
	}
	
}
