package LLD_Patterns.Factory;

public interface Vechile {

}
