package LLD_Patterns.Factory;

public interface VechileFactory1 {
	Vechile getCar(String car);
}
