package LLD_Patterns.Factory;

public class Ordinary {

}
