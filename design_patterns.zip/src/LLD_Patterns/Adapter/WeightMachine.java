package LLD_Patterns.Adapter;

public interface WeightMachine {
	
	double convertToKgs();
}
