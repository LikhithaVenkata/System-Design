package LLD_Patterns.Adapter;

public interface WeightInPounds {
	
	public double getWeightInPounds();
}
