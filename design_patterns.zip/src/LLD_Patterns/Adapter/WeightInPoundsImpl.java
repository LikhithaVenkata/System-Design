package LLD_Patterns.Adapter;

public class WeightInPoundsImpl implements WeightInPounds{

	@Override
	public double getWeightInPounds() {
		// TODO Auto-generated method stub
		return 20;
	}

}
