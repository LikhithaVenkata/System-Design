package VendingMachine;

public enum ItemType {
	coke,
	pepsi,
	juice,
	soda;	
}