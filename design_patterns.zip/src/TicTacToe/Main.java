package TicTacToe;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game game=new Game();
		System.out.println("Game winner is :" + game.startGame());
	}

}
