package TicTacToe;

public enum PieceType {
	X,
	O;
}
